Suspenders
======

React-js app or component

## Setup

run `npm install`

run `broccoli serve`

## deploy

run `broccoli build build` where the second build stands for the directory the
build is placed in.
