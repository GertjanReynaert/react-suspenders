/** @jsx React.DOM */
var App = React.createClass({
  render: function() {
    return (
      <div className="container">
        <h1>Suspenders</h1>
        <h2>Thanks for using react-suspenders</h2>
      </div>
    );
  }
});
