/** @jsx React.DOM */
React.renderComponent(<App/>, document.getElementById('app'));
